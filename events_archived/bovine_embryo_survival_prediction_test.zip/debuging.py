import cv2
video = cv2.VideoCapture("./data/test/V260.mp4")
print("all good")